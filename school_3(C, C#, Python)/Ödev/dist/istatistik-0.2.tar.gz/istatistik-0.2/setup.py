# -*- coding: utf-8 -*-
from setuptools import setup

setup(name='istatistik',
      version='0.2',
      description='Statistics module for learning purposes.',
      url='https://github.com/yavuzovski/playground/tree/master/school_3(C%2C%20C%23%2C%20Python)/%C3%96dev/seriler',
      author='Oğuzcan Yavuz',
      author_email='oguzcanyavuz321@gmail.com',
      license='GPLv3',
      packages=['istatistik']
)
